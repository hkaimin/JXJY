package com.codegen.common;

import java.io.Serializable;
/**
 *  应用程序实体对象基类
 * <B><P>EST-BPM -- http://www.jee-soft.cn</P></B>
 * <B><P>Copyright (C) 2008-2010 GuangZhou HongTian Software Company (广州宏天软件有限公司)</P></B> 
 * <B><P>description:</P></B>
 * <P>应用程序对象基类</P>
 * <P>product:HtCodeGen</P>
 * <P></P> 
 * @see com.codegen.common.ApplicationObject
 * <P></P>
 * @author 
 * @version V1
 * @create: 2010-11-19上午10:19:45
 */
public class ApplicationObject implements Serializable {
	
}