package com.codegen.common;

import com.codegen.db.Dbconn;
import com.codegen.db.SqlTable;

import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.Vector;
/**
 *  应用程序的基本配置属性
 * <B><P>EST-BPM -- http://www.jee-soft.cn</P></B>
 * <B><P>Copyright (C) 2008-2010 GuangZhou HongTian Software Company (广州宏天软件有限公司)</P></B> 
 * <B><P>description:</P></B>
 * <P>应用程序配置类</P>
 * <P>product:HtCodeGen</P>
 * <P></P> 
 * @see com.codegen.common.ApplicationProperties
 * <P></P>
 * @author 
 * @version V1
 * @create: 2010-11-19上午10:20:54
 */
public class ApplicationProperties extends ApplicationObject {
	public static String framework = "hotent";
	protected static String propertiesFileName = "generator";
	protected static Properties properties = null;
	protected static Vector excludeProperties = null;
	protected static Vector includeProperties = null;
	protected static List singleKeyGenerator = null;
	protected static String generatorClass = null;
	protected static String mvcFramework = "";
	protected static ListHashtable sqlTables = null;
	protected static ListHashtable pojoNames = null;
	private Dbconn dbconn = null;

	public static boolean forcedOverwrite = false;

	public static boolean removeCode = false;

	public ApplicationProperties() {
	}

	public ApplicationProperties(Properties aProp) {
		properties = aProp;
	}

	public static String getUseCaseSensitiveNames() {
		return getProperty("useCaseSensitiveNames");
	}

	public static String getFramework() {
		return getProperty("framework");
	}

	public static String getDbSchema() {
		return getProperty("dbSchema");
	}

	public static String getDbUrl() {
		return getProperty("dbUrl");
	}

	public static String getDbUserid() {
		return getProperty("dbUserid");
	}

	public static String getDbPasswd() {
		return getProperty("dbPasswd");
	}

	public static String getJdbcDriver() {
		return getProperty("jdbcDriver");
	}

	public static String getModelTemplate() {
		return getProperty("modelTemplate");
	}

	public static synchronized Properties getDefaultProperties() {
		return getDefaultProperties(propertiesFileName);
	}

	public static Properties getDefaultProperties(String fileName) {
		
		System.out.println("filename:" + fileName);
		System.out.println("read from generator.properties===================");
//		if(fileName.indexOf("conf")==-1){
//			String FS = File.separator;
//			fileName="." + FS + "conf" + FS+fileName;
//		}
		PropertyResourceBundle configBundle = (PropertyResourceBundle) PropertyResourceBundle.getBundle(fileName);
		System.out.println("name: read from properties");
		
		Properties newProp = new Properties();
		Enumeration keys = configBundle.getKeys();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			
			String value = (String) configBundle.getObject(key);
			System.out.println("keys:" + key + " val:" + value);
			newProp.put(key, value);
			if ((!Functions.hasMask(value, "Template"))
					|| (Functions.hasMask(value, "Common")))
				continue;
			int pos = value.indexOf("Template");
			if (pos > 0) {
				mvcFramework = value.substring(0, pos);
			}

		}
		return newProp;
	}

	public static Properties getProperties() {
		synchronized (ApplicationProperties.class) {
			if (properties == null) {
				properties = getDefaultProperties();
			}
		}

		return properties;
	}

	public static String getProperty(String aKey) {
		String propVal = "";
		try {
			propVal = getProperties().getProperty(aKey);
			if (propVal == null)
				throw new Exception("Property value null for " + aKey);
		} catch (Exception e) {
			System.out.println("Property " + aKey
					+ " Not found in properties file, error message:" + e.getMessage());
			propVal = "";
		}
		return propVal;
	}

	public static Vector getExcludeProperties() {
		if (excludeProperties == null) {
			initExcludeProperties();
		}
		return excludeProperties;
	}

	public static Vector getIncludeProperties() {
		if (includeProperties == null) {
			initIncludeProperties();
		}
		return includeProperties;
	}

	public static boolean isExcludedProperty(String template) {
		boolean exclude = false;
		int numProp = getExcludeProperties().size();
		for (int i = 0; i < numProp; i++) {
			String mask = (String) getExcludeProperties().elementAt(i);
			if (Functions.hasMask(template, mask)) {
				exclude = true;
				break;
			}
		}

		if (!exclude) {
			exclude = !isIncludedProperty(template);
		}
		return exclude;
	}

	public static boolean isIncludedProperty(String template) {
		boolean include = true;
		int numProp = getIncludeProperties().size();
		if (numProp > 0)
			include = false;
		else {
			return include;
		}
		for (int i = 0; i < numProp; i++) {
			String mask = (String) getIncludeProperties().elementAt(i);
			if (Functions.hasMask(template, mask)) {
				include = true;
				break;
			}
		}
		return include;
	}

	public static void initExcludeProperties() {
		excludeProperties = new Vector();
		String exclude = getProperty("exclude");
		if (exclude.equals(""))
			return;
		excludeProperties = StringUtil.parseToVector(exclude, ",");
	}

	public static void initIncludeProperties() {
		includeProperties = new Vector();
		String include = getProperty("include");
		if (include.equals(""))
			return;
		includeProperties = StringUtil.parseToVector(include, ",");
	}

	public static List getSingleKeyGenerator() {
		if (singleKeyGenerator == null) {
			singleKeyGenerator = new ArrayList();
			generatorClass = "";
			String val = getProperty("singleKeyGenerator");
			if (!val.equals("")) {
				Vector t1 = StringUtil.parseToVector(val, ":,");
				int num = t1.size();
				if (num > 0)
					generatorClass = (String) t1.elementAt(0);
				for (int i = 1; i < num; i++) {
					String elem = (String) t1.elementAt(i);
					singleKeyGenerator.add(elem);
				}
			}
		}
		return singleKeyGenerator;
	}

	public static boolean isGeneratedKey(SqlTable aTable) {
		boolean genKey = aTable.getHasSingleKey();

		if (genKey) {
			String keyType = aTable.getPrimaryKey(0).getAttType();
			if (keyType.indexOf(".") > 0) {
				keyType = StringUtil.trimToLastDot(keyType);
			}
			List genList = getSingleKeyGenerator();
			if (!genList.contains(keyType)) {
				genKey = false;
			}
		}
		return genKey;
	}

	public String toString() {
		return getProperties().toString();
	}

	public static String getPropertiesFileName() {
		return propertiesFileName;
	}

	public static void setPropertiesFileName(String propertiesFileName) {
		propertiesFileName = propertiesFileName;
	}

	public static String getMvcFramework() {
		return mvcFramework;
	}

	public static void destroyProperties() {
		properties = null;
	}

	public static String getGeneratorClass() {
		return generatorClass;
	}

	public static ListHashtable getSqlTables() {
		if (sqlTables == null) {
			sqlTables = new ListHashtable();
		}
		return sqlTables;
	}

	public static SqlTable getSqlTable(String tableName) {
		if (getSqlTables().containsKey(tableName)) {
			return (SqlTable) getSqlTables().get(tableName);
		}
		return null;
	}

	public static ListHashtable getPojoNames() {
		if (pojoNames == null) {
			initPojoNames();
		}
		return pojoNames;
	}

	private static void initPojoNames() {
		String entityNamesFile = "pojoNames";
		FileUtility flUtil = new FileUtility();
		try {
			pojoNames = flUtil.getInputFileAsListHashtable(entityNamesFile);
		} catch (Exception e) {
			System.out
					.println("Exception encountered reading entityNamesFile: "
							+ entityNamesFile);
			System.out.println(e.getMessage());
			throw new RuntimeException(e);
		}
	}
}