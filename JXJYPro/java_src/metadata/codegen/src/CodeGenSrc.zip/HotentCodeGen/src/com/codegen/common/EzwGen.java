package com.codegen.common;

import com.codegen.db.SqlColumn;
import com.codegen.db.SqlTable;

import java.util.HashMap;
import java.util.List;

public class EzwGen extends ApplicationObject {
	private static final int maxLength = 40;
	private static final String blank15 = "               ";
	private SqlTable sqlTable;
	private StringBuffer selectStmt;
	private StringBuffer updateStmt;
	private StringBuffer insertStmt;
	private StringBuffer valueStmt;
	private StringBuffer deleteStmt;
	private StringBuffer populateList;
	private StringBuffer insertList;
	private StringBuffer updateList;
	private int numColumns = 0;

	private void createSqlStatements() {
		HashMap columns = this.sqlTable.getAllColumns();
		List sqlColumns = this.sqlTable.getSqlColumns();
		String crlf = Functions.crlf;

		this.selectStmt = new StringBuffer(quote("SELECT "));
		this.updateStmt = new StringBuffer(quote("UPDATE ") + " + tableName + "
				+ quote(" SET "));
		this.deleteStmt = new StringBuffer(quote("DELETE FROM ")
				+ " + tableName ");
		this.insertStmt = new StringBuffer(quote("INSERT INTO ")
				+ " + tableName ");
		this.valueStmt = new StringBuffer("");

		this.numColumns = sqlColumns.size();
		SqlColumn aCol = (SqlColumn) sqlColumns.get(0);
		String colname = aCol.getColname();
		StringBuffer selectTemp = new StringBuffer("a." + colname);
		StringBuffer updateTemp = new StringBuffer(colname + " = ? ");
		StringBuffer insertTemp = new StringBuffer("( " + colname);
		StringBuffer valueTemp = new StringBuffer("VALUES ( ? ");
		this.updateList = new StringBuffer();
		this.populateList = new StringBuffer();
		this.insertList = new StringBuffer();

		colname = "";
		int updateColNum = 0;
		String entity = Functions.makeClassName(this.sqlTable.getEntityName());
		String entityVar = Functions.makeFirstLetterLowerCase(entity);
		String attrName = attrName = Functions.makeFirstLetterUpperCase(aCol
				.getBusinessAttributeVar());
		updateColNum = appendToLists(false, updateColNum, entityVar, 1, aCol,
				attrName);
		for (int i = 1; i < this.numColumns - 1; i++) {
			aCol = (SqlColumn) sqlColumns.get(i);
			colname = aCol.getColname();
			process(selectTemp, this.selectStmt, "a." + colname, false);
			process(updateTemp, this.updateStmt, colname + " = ? ", false);
			process(insertTemp, this.insertStmt, colname, false);
			process(valueTemp, this.valueStmt, "?", false);

			SqlColumn col = (SqlColumn) columns.get(colname);
			attrName = Functions.makeFirstLetterUpperCase(col
					.getBusinessAttributeVar());
			updateColNum = appendToLists(true, updateColNum, entityVar, i + 1,
					col, attrName);
		}

		int lastCol = this.numColumns - 1;
		aCol = (SqlColumn) sqlColumns.get(lastCol);
		attrName = Functions.makeClassName(aCol.getAttName());
		colname = aCol.getColname();
		process(selectTemp, this.selectStmt, "a." + colname, true);
		process(updateTemp, this.updateStmt, colname + " = ?  ", true);
		process(insertTemp, this.insertStmt, colname + " ) ", true);
		process(valueTemp, this.valueStmt, "?  ) ", true);

		attrName = Functions.makeFirstLetterUpperCase(aCol
				.getBusinessAttributeVar());
		updateColNum = appendToLists(true, updateColNum, entityVar,
				this.numColumns, aCol, attrName);
	}

	protected int appendToLists(boolean prefixBlanks, int updateColNum,
			String entityVar, int i, SqlColumn col, String attrName) {
		String crlf = Functions.crlf;
		String entityVar2 = entityVar;
		if (prefixBlanks) {
			entityVar = "    " + entityVar;
		}
		this.populateList.append(entityVar + "Tbl.get" + attrName
				+ "().setOriginalDbValue(resultSet," + i + ");" + crlf);
		this.insertList.append(entityVar + "Tbl.get" + attrName
				+ "().getColumnValue(sqlStatement," + i + ");" + crlf);
		if (!col.isKey()) {
			updateColNum++;
			if (updateColNum > 1)
				entityVar2 = "    " + entityVar2;
			this.updateList.append(entityVar2 + "Tbl.get" + attrName
					+ "().getColumnValue(sqlStatement," + updateColNum + ");"
					+ crlf);
		}
		return updateColNum;
	}

	public static EzwGen getEzwGen(SqlTable aTable) {
		EzwGen ezw = new EzwGen(aTable);
		return ezw;
	}

	public EzwGen(SqlTable aTable) {
		this.sqlTable = aTable;
		createSqlStatements();
	}

	private static String quote(String aString) {
		return Functions.quote(aString);
	}

	private static void process(StringBuffer tempBuf, StringBuffer buf,
			String nxtString, boolean flushBuffer) {
		int numChars = tempBuf.toString().length() + nxtString.length();
		if (numChars > 40) {
			buf.append(Functions.crlf + "               " + " + "
					+ quote(tempBuf.toString()));
			tempBuf.setLength(0);
			tempBuf.append(", " + nxtString);
		} else {
			tempBuf.append(", " + nxtString);
		}
		if (flushBuffer) {
			buf.append(Functions.crlf + "               " + " + "
					+ quote(tempBuf.toString()));
			tempBuf.setLength(0);
		}
	}

	public StringBuffer getDeleteStmt() {
		return this.deleteStmt;
	}

	public StringBuffer getInsertStmt() {
		return this.insertStmt;
	}

	public StringBuffer getSelectStmt() {
		return this.selectStmt;
	}

	public StringBuffer getUpdateStmt() {
		return this.updateStmt;
	}

	public StringBuffer getValueStmt() {
		return this.valueStmt;
	}

	public StringBuffer getInsertList() {
		return this.insertList;
	}

	public int getNumColumns() {
		return this.numColumns;
	}

	public StringBuffer getPopulateList() {
		return this.populateList;
	}

	public StringBuffer getUpdateList() {
		return this.updateList;
	}
}