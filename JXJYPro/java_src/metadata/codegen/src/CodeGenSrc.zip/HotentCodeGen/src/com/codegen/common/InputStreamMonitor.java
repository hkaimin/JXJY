package com.codegen.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;

public class InputStreamMonitor extends Thread {
	private InputStream inputStream;

	public InputStreamMonitor(InputStream is) {
		this.inputStream = is;
		start();
	}

	public void run() {
		try {
			while (true) {
				int value = this.inputStream.read();
				if (value == -1) {
					return;
				}
				System.out.write(value);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}