package com.codegen.common;

import java.util.List;

public class PackageNameResolver extends PropertiesResolver {
	private static PackageNameResolver packageNameResolver = null;

	public static void destroyResolver() {
		packageNameResolver = null;
	}

	public static PackageNameResolver getResolver() {
		if (packageNameResolver == null) {
			packageNameResolver = new PackageNameResolver();
		}
		return packageNameResolver;
	}

	public String getFileKey() {
		return "packageNameResolver";
	}

	public String getPropertyValue(String lookupKey, boolean lookupDefault) {
		String propertyValue = "";
		ListHashtable propValues = getPropertyValues();

		List orderedKeys = propValues.getOrderedKeys();
		int numValues = orderedKeys.size();
		for (int i = 0; i < numValues; i++) {
			String key = (String) orderedKeys.get(i);
			String value = (String) propValues.get(key);
			if ((lookupKey.equals(key))
					|| (lookupKey.equals(key.toUpperCase()))) {
				propertyValue = value;
				break;
			}
		}
		if ((propertyValue.equals("")) && (lookupDefault)) {
			throw new RuntimeException("Package not defined for:" + lookupKey);
		}

		do {
			propertyValue = resolveParms(propertyValue);
		} while (Functions.hasMask(propertyValue, "${"));

		return propertyValue;
	}
}