package com.codegen.common;

public class StringExclusionFilter {
	private boolean excludeSectionFound = false;
	private String excludeFilter = "";
	private String includeString = "";
	private int numSections = 0;

	public StringExclusionFilter(String exc, String inc) {
		this.excludeFilter = exc;
		this.includeString = inc;
	}

	public String processLine(String inputLine) {
		String outputLine = inputLine;
		boolean lineHasMask = inputLine.indexOf(this.excludeFilter) >= 0;
		if (this.excludeSectionFound) {
			outputLine = null;
			if (lineHasMask) {
				if (!ApplicationProperties.removeCode) {
					outputLine = this.includeString;
				}
				this.excludeSectionFound = false;
				return outputLine;
			}

		} else if (lineHasMask) {
			this.excludeSectionFound = true;
			outputLine = null;
			this.numSections += 1;
		}

		return outputLine;
	}

	public int getNumSections() {
		return this.numSections;
	}

	public boolean isExcludeSectionFound() {
		return this.excludeSectionFound;
	}

	public void setExcludeSectionFound(boolean excludeSectionFound) {
		this.excludeSectionFound = excludeSectionFound;
	}

	public void setNumSections(int numSections) {
		this.numSections = numSections;
	}
}