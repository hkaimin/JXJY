package com.codegen.common;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

public class StringUtil extends ApplicationObject {
	public static final String START_CAPTURE_TAG = "<!-- StartReportCapture -->";
	public static final String END_CAPTURE_TAG = "<!-- EndReportCapture -->";
	public static char[] crchar = { '\r', '\n' };
	public static String crlf = new String(crchar);
	public static char cr = '\r';
	public static char lf = '\n';
	public static String $crlf = "$crlf";

	public static final String assignString(String inString, int startPosition,
			int charLength) {
		String retString = new String("");
		int size = inString.length();
		if (startPosition <= size) {
			int endPosition = charLength + startPosition - 1;
			if (endPosition >= size)
				retString = inString.substring(startPosition - 1);
			else
				retString = inString.substring(startPosition - 1, endPosition);
		}
		return retString;
	}

	public static final String captureFromHtml(String inString,
			String startTag, String endTag) {
		String result = "";
		String inUcase = inString.toUpperCase();

		int startCaptureIdx = 0;
		int endCaptureIdx = inString.length();
		int remainIdx = 0;

		startTag = replaceString(startTag, ">", "").toUpperCase();
		endTag = replaceString(endTag, ">", "").toUpperCase();

		int startTagIdx = inUcase.indexOf(startTag.toUpperCase());
		if (startTagIdx >= 0)
			startCaptureIdx = inUcase.indexOf(">", startTagIdx) + 1;
		int endTagIdx = inUcase.indexOf(endTag.toUpperCase());
		if (endTagIdx >= 0) {
			endCaptureIdx = endTagIdx;
			remainIdx = inUcase.indexOf(">", endTagIdx) + 1;
		}

		if ((startTagIdx < 0) && (endTagIdx < 0)) {
			return result;
		}
		result = result + inString.substring(startCaptureIdx, endCaptureIdx);

		if (endTagIdx >= 0) {
			result = result
					+ captureFromHtml(inString.substring(remainIdx), startTag,
							endTag);
		}
		return result;
	}

	public static final Vector chopString(String inString, int size) {
		Vector result = new Vector();
		if (inString.length() == 0) {
			return result;
		}
		String curString = inString;
		while (true) {
			if (curString.length() <= size) {
				result.addElement(curString);
				return result;
			}
			result.addElement(curString.substring(0, size));
			curString = curString.substring(size);
		}
	}

	public static final String convToNum(String inString) {
		StringBuffer retStr = new StringBuffer();

		String tempStr = inString.toUpperCase();
		if (tempStr.indexOf("-") >= 0)
			retStr.append("-");
		for (int i = 0; i < inString.length(); i++) {
			char c = inString.charAt(i);
			if ((Character.isDigit(c)) || (c == '.'))
				retStr.append(c);
		}
		return retStr.toString();
	}

	public static final Serializable deserializeFromString(String aString)
			throws Exception {
		ByteArrayInputStream inStream = new ByteArrayInputStream(
				aString.getBytes());
		ObjectInputStream objInStream = new ObjectInputStream(inStream);
		Serializable myObject = (Serializable) objInStream.readObject();
		return myObject;
	}

	public static String getParameter(String parmStr, String searchStr,
			String separator) {
		String result = "";
		if ((searchStr == null) || (parmStr == null)) {
			return result;
		}
		StringTokenizer tline = new StringTokenizer(parmStr, separator);
		while (tline.hasMoreTokens()) {
			String value = tline.nextToken().trim();
			if (value.equals(searchStr)) {
				if (!tline.hasMoreTokens())
					break;
				result = tline.nextToken().trim();
				break;
			}
		}
		return result;
	}

	public static final String getStackTrace(Throwable e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		String stackTrace = sw.toString();
		return stackTrace;
	}

	public static final String htmlEncode(String inString) {
		String result = inString;

		result = replaceString(result, "\"", "&quot;");
		result = replaceString(result, ">", "&gt;");
		result = replaceString(result, "<", "&lt;");
		result = replaceString(result, "\n", "<BR>");
		return result;
	}

	public static final String javaScriptEncode(String inString) {
		String result = inString;

		result = replaceString(result, "\"", "\\\"");
		return result;
	}

	public static final boolean isDigit(String inString) {
		for (int i = 0; i < inString.length(); i++) {
			char c = inString.charAt(i);
			if (!Character.isDigit(c))
				return false;
		}
		return true;
	}

	public static final boolean isLetter(String inString) {
		for (int i = 0; i < inString.length(); i++) {
			char c = inString.charAt(i);
			if (!Character.isLetter(c))
				return false;
		}
		return true;
	}

	public static String makeUpperCaseAfterDot(String aStr) {
		String result = aStr;
		int i = 0;

		while (i < aStr.length()) {
			int dotPos = result.indexOf(".", i);
			if (dotPos < 0) {
				i = aStr.length();
			} else {
				i = dotPos + 1;
				result = result.substring(0, i)
						+ result.substring(i, i + 1).toUpperCase()
						+ result.substring(i + 1);
			}
		}

		return result;
	}

	public static String makeVarName(String newStr) {
		StringBuffer retstr = new StringBuffer("");
		String specialCharacters = " _/.,#'%-";
		String numericCharacters = "0123456789";
		int strlen = newStr.length();
		char[] onechar = new char[1];
		boolean nextUpper = false;
		boolean firstChar = true;

		for (int i = 0; i < strlen; i++) {
			onechar[0] = newStr.charAt(i);
			String charString = new String(onechar);
			if (specialCharacters.indexOf(charString) >= 0) {
				if (charString.equals("'"))
					nextUpper = false;
				else {
					nextUpper = true;
				}
			} else if (nextUpper) {
				if (!firstChar)
					retstr.append(charString.toUpperCase());
				else
					retstr.append(charString.toLowerCase());
				firstChar = false;
				nextUpper = false;
			} else {
				retstr.append(charString.toLowerCase());
				firstChar = false;
			}

		}

		if (numericCharacters.indexOf(String.valueOf(retstr.charAt(0))) >= 0) {
			retstr = retstr.insert(0, 'x');
		}
		return retstr.toString();
	}

	public static final String pad(String line, char padchar, int len) {
		int templen = len;
		if (templen < 0)
			templen *= -1;
		int numchar = templen - line.length();
		String retline = line;
		if (numchar > 0) {
			for (int i = 0; i < numchar; i++)
				if (len >= 0)
					retline = retline + padchar;
				else
					retline = padchar + retline;
		} else {
			retline = line.substring(0, templen);
		}
		return retline;
	}

	public static final Hashtable parseQueryString(String aQueryString) {
		Hashtable result = new Hashtable();

		if (aQueryString == null) {
			return result;
		}
		StringTokenizer tline = new StringTokenizer(aQueryString, "&");
		while (tline.hasMoreTokens()) {
			String tokstr = tline.nextToken();
			int pos = tokstr.indexOf("=");
			if (pos > 0) {
				String key = tokstr.substring(0, pos);
				String value = tokstr.substring(pos + 1);
				Object obj = result.get(key);
				if (obj == null) {
					result.put(key, value);
				} else if ((obj instanceof Vector)) {
					Vector v = (Vector) obj;
					v.addElement(value);
				} else {
					Vector v = new Vector();
					v.addElement(obj);
					v.addElement(value);
					result.put(key, v);
				}
			}
		}
		return result;
	}

	public static final Vector parseString(String aQueryString, String delimiter) {
		Vector result = new Vector();

		if (aQueryString == null) {
			return result;
		}
		StringTokenizer tline = new StringTokenizer(aQueryString, delimiter);
		while (tline.hasMoreTokens()) {
			String tokstr = tline.nextToken();
			result.addElement(tokstr);
		}
		return result;
	}

	public static final Vector parseToVector(String aString, int numChars) {
		Vector result = new Vector();

		if ((aString == null) || (numChars <= 0)) {
			return result;
		}
		int len = aString.length();
		int currPos = 0;
		int endPos = numChars;
		while (currPos <= len) {
			String subStr = aString.substring(currPos, endPos).trim();
			if (subStr.equals(""))
				break;
			result.addElement(subStr);

			currPos = endPos;
			endPos += numChars;
			if (endPos <= len)
				continue;
			endPos = len;
		}
		return result;
	}

	public static final Vector parseToVector(String aString, String separator) {
		Vector result = new Vector();

		if (aString == null) {
			return result;
		}
		StringTokenizer tline = new StringTokenizer(aString, separator);
		while (tline.hasMoreTokens()) {
			String value = tline.nextToken().trim();
			result.addElement(value);
		}
		return result;
	}

	public static final String parseToYearMonth(String aValue) {
		if ((aValue.length() != 6) && (aValue.length() != 7))
			return null;

		SimpleDateFormat df = new SimpleDateFormat();
		df.setLenient(false);
		if (aValue.length() == 7)
			df.applyPattern("yyyy/MM");
		else
			df.applyPattern("yyyyMM");
		try {
			df.parse(aValue);
		} catch (ParseException localParseException) {
		}
		if (aValue.length() == 6) {
			return aValue.substring(0, 4) + "/" + aValue.substring(4, 6);
		}
		return aValue;
	}

	public static final String readToString(File inFile) throws IOException {
		return readToString(new FileInputStream(inFile));
	}

	public static final String readToString(InputStream inputStream)
			throws IOException {
		BufferedReader r = new BufferedReader(
				new InputStreamReader(inputStream));
		StringBuffer resultBuffer = new StringBuffer();

		char[] cbuf = new char[4096];
		int i;
		do {
			i = r.read(cbuf);
			if (i >= 0)
				resultBuffer.append(cbuf, 0, i);
		} while (i >= 0);

		r.close();

		return resultBuffer.toString();
	}

	public static final String removeLeadingChar(String value, char ch) {
		int len = value.length();
		char[] val = value.toCharArray();
		int st = 0;

		while ((st < len) && (val[st] == ch))
			st++;

		return st > 0 ? value.substring(st, len) : value;
	}

	public static final String removeTrailingBlanks(String value) {
		int len = value.length();
		char[] val = value.toCharArray();

		while ((len > 0) && (val[(len - 1)] <= ' ')) {
			len--;
		}

		return value.substring(0, len);
	}

	public static final String replaceParameterValues(String aString,
			String parameterValues, String separator) {
		String result = aString;
		Vector parmValues = parseString(parameterValues, separator);
		int numParms = parmValues.size();
		for (int i = 0; i < numParms; i++) {
			String aParmValue = (String) parmValues.elementAt(i);
			Vector parmPair = parseString(aParmValue, "=");
			String fromStr = (String) parmPair.elementAt(0);
			String toStr = (String) parmPair.elementAt(1);
			result = replaceString(result, fromStr, toStr);
		}
		return result;
	}

	public static final String replaceString(String in, String from, String to) {
		int i = in.indexOf(from);
		if ((i < 0) || (from.length() == 0)) {
			return in;
		}
		return in.substring(0, i) + to
				+ replaceString(in.substring(i + from.length()), from, to);
	}

	public static final String serializeToString(Serializable myObject)
			throws IOException {
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		ObjectOutputStream objOutStream = new ObjectOutputStream(byteStream);

		objOutStream.writeObject(myObject);

		return byteStream.toString();
	}

	public static final String trimAfterLastDot(String line) {
		int lastDot = line.lastIndexOf(".");
		int size = line.length();
		if (lastDot >= 0) {
			return line.substring(0, lastDot).trim();
		}
		return line.trim();
	}

	public static final String trimBeforeLastDot(String line) {
		int lastDot = line.lastIndexOf(".");
		int size = line.length();
		if (lastDot >= 0) {
			return line.substring(0, lastDot).trim();
		}
		return line.trim();
	}

	public static final String trimToFirstDot(String line) {
		return trimToFirstMarker(".", line);
	}

	public static final String trimToFirstDash(String line) {
		return trimToFirstMarker("-", line);
	}

	public static final String trimToFirstMarker(String marker, String line) {
		int firstMarker = line.indexOf(marker);
		int size = line.length();
		if (firstMarker > 0) {
			return line.substring(0, firstMarker).trim();
		}
		return line.trim();
	}

	public static final String trimToLastDot(String line) {
		return trimToLastMarker(".", line);
	}

	public static final String trimToLastDash(String line) {
		return trimToLastMarker("-", line);
	}

	public static final String trimToLastMarker(String marker, String line) {
		int lastMarker = line.lastIndexOf(marker);
		int size = line.length();
		if (lastMarker >= 0) {
			if (size > lastMarker + 1)
				return line.substring(lastMarker + 1).trim();
			return "";
		}
		return line.trim();
	}

	public static final String truncateString(String inString, int size) {
		String result = "";
		if (inString.length() == 0) {
			return result;
		}
		String curString = inString;

		if (curString.length() <= size)
			result = curString;
		else
			result = curString.substring(0, size);
		return result;
	}

	public static final String vectorToString(Vector aVector, String separator) {
		String result = "";

		for (int i = 0; i < aVector.size(); i++) {
			if (i > 0)
				result = result + separator;
			result = result + aVector.elementAt(i);
		}

		return result;
	}

	public static final void writeString(String aString, File outFile)
			throws IOException {
		try {
			FileWriter w = new FileWriter(outFile);

			w.write(aString);
			w.close();
		} catch (IOException e) {
			throw new IOException(outFile.toString() + " cannot be written");
		}
	}

	public static String byteArrayToCommaDelimitedString(byte[] byteArray) {
		int numBytes = byteArray.length;
		StringBuffer output = new StringBuffer();
		for (int i = 0; i < numBytes; i++) {
			if (i > 0)
				output.append(",");
			output.append(byteArray[i]);
		}
		return output.toString();
	}

	public static byte[] commaDelimitedStringToByteArray(String inputString) {
		Vector byteVector = parseToVector(inputString, ",");
		int numBytes = byteVector.size();
		byte[] output = new byte[numBytes];
		for (int i = 0; i < numBytes; i++) {
			String val = (String) byteVector.elementAt(i);
			Byte byteVal = new Byte(val);
			output[i] = byteVal.byteValue();
		}
		return output;
	}
}