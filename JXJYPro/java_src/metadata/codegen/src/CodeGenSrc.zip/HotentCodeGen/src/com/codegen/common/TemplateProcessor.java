package com.codegen.common;

import com.codegen.db.SqlTable;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
/**
 * 模板处理器
 * @author csx
 *
 */
public class TemplateProcessor extends ApplicationObject {
	private Properties properties;
	private VelocityEngine vengine = null;

	private static PackageNameResolver packageResolver = null;

	private static FileLocationResolver fileResolver = null;

	private static FileNameResolver fileNameResolver = null;

	public TemplateProcessor(Properties inputProperties) {
		this.properties = inputProperties;
		initResolvers();
	}

	public void process(VelocityContext context) throws Exception {
		initVelocity(this.properties.getProperty("templateLocation"));

		initRequestProperties(context);
		generateSourceFiles(context);
		generatePropertyFiles(context);
		generateNoParseFiles(context);
		generateFileLists(context);
	}

	public void initRequestProperties(VelocityContext context) {
		SqlTable sqlTable = (SqlTable) context.get("sqlTable");
		ListHashtable resolvedProperties = Functions
				.getResolvedProperties(sqlTable);
		ThreadContext.getCurrentContext().getRequestProperties()
				.merge(resolvedProperties);
		String packageMod = (String) resolvedProperties.get("packageMod");
		String packageModot = (String) resolvedProperties.get("packageModot");

		ApplicationProperties.getProperties().put("packageMod", packageMod);
		ApplicationProperties.getProperties().put("packageModot", packageModot);
	}

	private void initResolvers() {
		if (fileResolver == null) {
			fileResolver = new FileLocationResolver();
		}
		if (packageResolver == null) {
			packageResolver = new PackageNameResolver();
		}
		if (fileNameResolver == null)
			fileNameResolver = new FileNameResolver();
	}

	private void initVelocity(String templateDirectory) throws Exception {
		Properties p = new Properties();
		p.put("file.resource.loader.path", templateDirectory);
		p.put("input.encoding", "UTF-8");
		p.put("output.encoding", "UTF-8");
		this.vengine = new VelocityEngine();
		this.vengine.init(p);
	}

	private void generatePropertyFiles(VelocityContext context)
			throws Exception {
		SqlTable sqlTable = (SqlTable) context.get("sqlTable");
		String srcName = Functions.makeClassName(sqlTable.getEntityName());

		Properties embeddedList = Functions.extractProperties(this.properties,
				"Embedded");
		if (embeddedList.size() == 0)
			return;
		Enumeration enums = embeddedList.elements();
		while (enums.hasMoreElements()) {
			String embeddedParms = (String) enums.nextElement();
			while (Functions.hasMask(embeddedParms, "${")) {
				embeddedParms = PropertiesResolver.resolveParms(embeddedParms);
			}
			processEmbeddedTemplate(context, srcName, embeddedParms);
		}
	}

	private void generateSourceFiles(VelocityContext context) throws Exception {
		SqlTable sqlTable = (SqlTable) context.get("sqlTable");
		String entityName = Functions.makeClassName(sqlTable.getEntityName());

		Properties templateList = Functions.extractProperties(this.properties,
				"Template");
		if (templateList.size() == 0) {
			return;
		}

		Enumeration enums = templateList.keys();
		while (enums.hasMoreElements()) {
			String aKey = (String) enums.nextElement();
			String aValue = (String) templateList.get(aKey);
			Vector oneParm = StringUtil.parseToVector(aValue, "^");
			String template = (String) oneParm.elementAt(0);

			processTemplate(context, aKey, template);
		}
	}

	private void processEmbeddedTemplate(VelocityContext context,
			String srcName, String embeddedParms) throws Exception {
		String quote = Functions.quote;
		String crlf = Functions.crlf;

		Vector parms = StringUtil.parseToVector(embeddedParms, "^");
		String templateFile = ((String) parms.elementAt(0)).trim();
		System.out
				.println("--------------------------------------------------------------------------------");
		System.out.println("Class " + srcName
				+ "..Processing Embedded Template = " + templateFile);

		if (ApplicationProperties.isExcludedProperty(templateFile)) {
			System.out.println("Excluded Embedded File: " + templateFile
					+ " .... Skipped ...!");
			return;
		}

		String includeCommand = "#parse (" + quote + templateFile + quote + ")";
		String includeString = "";

		String excludeString = "";

		if ((parms.size() >= 4) || (templateFile.indexOf("_package") > 0))
			excludeString = " Generated for "
					+ ApplicationProperties.getProperty("packageMod")
					+ " From Template: " + templateFile;
		else {
			excludeString = " Generated for " + srcName + " From Template: "
					+ templateFile;
		}

		if (Functions.hasMask(templateFile, ".xml"))
			includeString = "<!-- start: " + excludeString + "  -->" + crlf
					+ includeCommand + crlf + crlf + "<!-- end: "
					+ excludeString + "  -->";
		else if (Functions.hasMask(templateFile, ".properties"))
			includeString = "#---- start: " + excludeString + FileUtility.crlf
					+ includeCommand + crlf + crlf + "#--- end: "
					+ excludeString;
		else if (Functions.hasMask(templateFile, ".jsp"))
			includeString = "<%-- start: " + excludeString + "  --%>" + crlf
					+ includeCommand + crlf + crlf + "<%-- end: "
					+ excludeString + "  --%>";
		else {
			includeString = "//  start: " + excludeString + crlf
					+ includeCommand + crlf + crlf + crlf + "//  end: "
					+ excludeString;
		}
		String relativeFileLoc = ((String) parms.elementAt(1)).trim();
		String inFileName = StringUtil.trimBeforeLastDot(templateFile);

		String inputFile = ApplicationProperties
				.getProperty("javaOutputLocation")
				+ relativeFileLoc
				+ inFileName;
		String outputFile = inputFile;

		File inFile = new File(inputFile);

		FileUtility flUtil = new FileUtility();

		StringBuffer stringTemplate = flUtil.getInputFileAsString(inFile,
				excludeString, includeString);
		if ((flUtil.getFilter().getNumSections() > 0)
				&& (!ApplicationProperties.forcedOverwrite)
				&& (!ApplicationProperties.removeCode)) {
			System.out
					.println("Original embedded content found but forcedOverwrite disabled, skip only.");
			return;
		}

		if ((flUtil.getFilter().getNumSections() == 0)
				&& (!ApplicationProperties.removeCode)) {
			String newMask = "";
			if (parms.size() >= 3) {
				newMask = ((String) parms.elementAt(2)).trim();
			}
			String currString = stringTemplate.toString();
			int pos = 0;
			boolean isMenuConfig = false;

			if ("<!--Menu mark-->".equals(newMask)) {
				isMenuConfig = true;
				newMask = "<!--end of "
						+ ApplicationProperties.getProperty("packageMod")
						+ " menu items-->";
			}
			if (!newMask.equals("")) {
				pos = currString.lastIndexOf(newMask);
			}
			if (pos > 0) {
				StringBuffer tempBuffer = new StringBuffer();
				tempBuffer.append(currString.substring(0, pos));
				tempBuffer.append(includeString);
				tempBuffer.append(crlf);
				tempBuffer.append(currString.substring(pos));
				stringTemplate = tempBuffer;
			} else if (newMask.equalsIgnoreCase("$BOF")) {
				StringBuffer tempBuffer = new StringBuffer(includeString);
				tempBuffer.append(crlf);
				tempBuffer.append(stringTemplate.toString());
				stringTemplate = tempBuffer;
			} else if (isMenuConfig) {
				pos = currString.lastIndexOf("</Menus>");
				if (pos < 0) {
					pos = currString.length();
				}
				StringBuffer tempBuffer = new StringBuffer();
				tempBuffer.append(currString.substring(0, pos));

				tempBuffer.append("#parse ("
						+ quote
						+ templateFile.substring(0,
								templateFile.lastIndexOf(".xml.vm"))
						+ "-package" + ".xml.vm" + quote + ")");
				tempBuffer.append(crlf);
				tempBuffer.append(crlf);
				tempBuffer.append(currString.substring(pos));
				stringTemplate = tempBuffer;
			}

			if ((newMask.equalsIgnoreCase("$EOF")) || (newMask.equals(""))) {
				stringTemplate.append(crlf);
				stringTemplate.append(includeString);
			}
		}

		File outFile = new File(outputFile + ".tmp");
		Functions.createDir(outFile);

		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(outFile), "UTF-8"));
		this.vengine
				.evaluate(context, writer, "LOG", stringTemplate.toString());
		writer.flush();
		writer.close();

		String backupContent = flUtil.getInputFileAsString(inFile).toString();
		String updatedContent = flUtil.getInputFileAsString(outFile).toString();

		if (updatedContent.equals(backupContent)) {
			System.out
					.println("##########Generated content is exactly the same as in existing file, skip only:"
							+ outputFile);
			outFile.delete();
			return;
		}
		inFile.delete();
		outFile.renameTo(new File(outputFile));
		System.out.println("Class "
				+ srcName
				+ "..Embedded File: "
				+ outputFile
				+ (ApplicationProperties.removeCode ? " code block removed!"
						: " generated/updated!"));
	}

	private void processTemplate(VelocityContext context, String keyName,
			String modelTemplate) throws Exception {
		if (ApplicationProperties.isExcludedProperty(modelTemplate)) {
			System.out.println("Excluded Template File: " + modelTemplate
					+ " .... Skipped ...!");
			return;
		}

		SqlTable table = (SqlTable) context.get("sqlTable");
		System.out
				.println("--------------------------------------------------------------------------------");
		System.out.println("Class "
				+ Functions.makeClassName(table.getEntityName())
				+ "..Processing Template = " + modelTemplate + "!");

		if ((modelTemplate.startsWith("PK")) && (!table.getHasCompositeKey())) {
			System.out.println("Excluded Template File: " + modelTemplate
					+ " .... No Composite Key Detected ...!");
			return;
		}

		String locationAndFileName = getLocationAndFileName(table,
				modelTemplate);
		File outFile = new File(locationAndFileName);

		if (ApplicationProperties.removeCode) {
			outFile.delete();
			System.out.println("Class "
					+ Functions.makeClassName(table.getEntityName())
					+ "..Generated File: " + locationAndFileName + " deleted!");
			return;
		}

		if ((Functions.hasMask(keyName, "NoOverwrite")) && (outFile.exists())) {
			if (!ApplicationProperties.forcedOverwrite) {
				System.out
						.println(".. Warning.. "
								+ locationAndFileName
								+ " Already exists.. forcedOverwrite disabled.. Generation skipped");
				return;
			}
			System.out
					.println(".. Warning.. "
							+ locationAndFileName
							+ " Already exists.. forcedOverwrite enabled.. Generation performed");
		}

		Template template = this.vengine.getTemplate(modelTemplate);
		Functions.createDir(outFile);

		File tmpFile = null;
		if (locationAndFileName.endsWith("\\")) {
			locationAndFileName = locationAndFileName.substring(0,
					locationAndFileName.length() - 1);
		}
		tmpFile = new File(locationAndFileName + ".tmp");

		BufferedWriter writer = new BufferedWriter(new FileWriter(tmpFile));
		template.merge(context, writer);
		writer.flush();
		writer.close();

		FileUtility flUtil = new FileUtility();
		String updatedContent = flUtil.getInputFileAsString(tmpFile).toString();
		String backupContent = null;
		if (outFile.exists()) {
			backupContent = flUtil.getInputFileAsString(outFile).toString();
		}

		if (updatedContent.equals(backupContent)) {
			System.out
					.println("##########Generated content is exactly the same as in existing file, skip only:"
							+ locationAndFileName);
			tmpFile.delete();
		} else {
			outFile.delete();
			tmpFile.renameTo(new File(locationAndFileName));
			System.out.println("Class "
					+ Functions.makeClassName(table.getEntityName())
					+ "..Template File: " + locationAndFileName
					+ " generated/updated!");
		}
	}

	private String getLocationAndFileName(SqlTable table, String template) {
		String javaOutputLocation = ApplicationProperties
				.getProperty("javaOutputLocation");
		String defaultOutputLocation = ApplicationProperties
				.getProperty("defaultOutputLocation");

		ThreadContext.setRequestProperties("EntityName",
				Functions.makeClassName(table.getEntityName()));
		ThreadContext.setRequestProperties("Table",
				Functions.makeClassName(table.getTable()));
		ThreadContext.setRequestProperties("TemplateName",
				StringUtil.trimBeforeLastDot(template));

		String outputFile = fileNameResolver.getPropertyValue(template);

		String locationAndFileName = defaultOutputLocation + outputFile;
		String lowercaseOutputFile = Functions
				.makeFirstLetterLowerCase(outputFile);
		ThreadContext.setRequestProperties("lowercaseOutputFile",
				lowercaseOutputFile);
		String resolvedLocation = fileResolver.getPropertyValue(template);

		if (!resolvedLocation.equals("")) {
			if (!javaOutputLocation.equals(""))
				locationAndFileName = javaOutputLocation + resolvedLocation;
			else
				locationAndFileName = defaultOutputLocation + resolvedLocation;
		}
		if (locationAndFileName.indexOf(lowercaseOutputFile) < 0)
			locationAndFileName = locationAndFileName + outputFile;
		return locationAndFileName;
	}

	private void generateFileLists(VelocityContext context) throws Exception {
		Properties velocityList = Functions.extractProperties(this.properties,
				"velocityList");
		if (velocityList.size() == 0) {
			return;
		}
		Enumeration enums = velocityList.elements();

		while (enums.hasMoreElements()) {
			String listFileName = (String) enums.nextElement();
			System.out
					.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			System.out.println("+++++ Processing template List: "
					+ listFileName);
			System.out
					.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			Properties fileProps = ApplicationProperties
					.getDefaultProperties(listFileName);
			TemplateProcessor templateProcessor = new TemplateProcessor(
					fileProps);
			templateProcessor.process(context);
		}
	}

	private void processNoParseTemplate(VelocityContext context,
			String srcName, String embeddedParms) throws Exception {
		String quote = Functions.quote;
		String crlf = Functions.crlf;

		Vector parms = StringUtil.parseToVector(embeddedParms, "^");
		String templateFile = ((String) parms.elementAt(0)).trim();
		System.out
				.println("--------------------------------------------------------------------------------");
		System.out.println("Class " + srcName
				+ "..Processing NoParse Template = " + templateFile);

		if (ApplicationProperties.isExcludedProperty(templateFile)) {
			System.out.println("Excluded NoParse File: " + templateFile
					+ " .... Skipped ...!");
			return;
		}

		String includeString = "";
		String relativeFileLoc = ((String) parms.elementAt(1)).trim();
		String inFileName = StringUtil.trimBeforeLastDot(templateFile);
		if (templateFile.indexOf("_package") > 0)
			inFileName = StringUtil.trimBeforeLastDot(templateFile
					.replaceFirst("_package", ""));
		else {
			inFileName = StringUtil.trimBeforeLastDot(templateFile);
		}

		String inputFile = ApplicationProperties
				.getProperty("javaOutputLocation")
				+ relativeFileLoc
				+ inFileName;
		String outputFile = inputFile;
		File tempFile = new File(outputFile + ".tmp");
		FileUtility flUtil = new FileUtility();

		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(tempFile), "UTF-8"));
		Template templ = this.vengine.getTemplate(templateFile);
		templ.merge(context, writer);
		writer.flush();
		String includeFileContents = flUtil.getInputFileAsString(tempFile)
				.toString();

		writer.close();
		templ = null;
		tempFile.delete();
		tempFile = null;

		String excludeString = null;
		if (templateFile.indexOf("_package") > 0)
			excludeString = " Generated for "
					+ ApplicationProperties.getProperty("packageMod")
					+ " From Template: " + templateFile;
		else {
			excludeString = " Generated for " + srcName + " From Template: "
					+ templateFile;
		}
		if (Functions.hasMask(templateFile, ".xml"))
			includeString = "<!-- start: " + excludeString + "  -->" + crlf
					+ includeFileContents + crlf + "<!-- end: " + excludeString
					+ "  -->";
		else if (Functions.hasMask(templateFile, ".properties"))
			includeString = "#---- start: " + excludeString + FileUtility.crlf
					+ includeFileContents + crlf + "#--- end: " + excludeString;
		else if (Functions.hasMask(templateFile, ".jsp"))
			includeString = "<%-- start: " + excludeString + "  --%>" + crlf
					+ includeFileContents + crlf + "<%-- end: " + excludeString
					+ "  --%>";
		else {
			includeString = "//  start: " + excludeString + crlf
					+ includeFileContents + crlf + crlf + crlf + "//  end: "
					+ excludeString;
		}

		File inFile = new File(inputFile);

		StringBuffer stringTemplate = flUtil.getInputFileAsString(inFile,
				excludeString, includeString);
		if ((flUtil.getFilter().getNumSections() > 0)
				&& (Functions.hasMask(templateFile, "NoOverwrite"))
				&& (!ApplicationProperties.removeCode)) {
			System.out
					.println("Original embedded content found but NoOverwrite detected, skip only.");
			return;
		}

		if ((flUtil.getFilter().getNumSections() == 0)
				&& (!ApplicationProperties.removeCode)) {
			String newMask = "";
			if (parms.size() >= 3) {
				newMask = ((String) parms.elementAt(2)).trim();
			}
			String currString = stringTemplate.toString();
			int pos = 0;
			if (!newMask.equals("")) {
				pos = currString.lastIndexOf(newMask);
			}
			if (pos > 0) {
				StringBuffer tempBuffer = new StringBuffer();
				tempBuffer.append(currString.substring(0, pos));
				tempBuffer.append(includeString);
				tempBuffer.append(crlf);
				tempBuffer.append(currString.substring(pos));
				stringTemplate = tempBuffer;
			} else if (newMask.equalsIgnoreCase("$BOF")) {
				StringBuffer tempBuffer = new StringBuffer(includeString);
				tempBuffer.append(crlf);
				tempBuffer.append(stringTemplate.toString());
				stringTemplate = tempBuffer;
			} else if ((newMask.equalsIgnoreCase("$EOF"))
					|| (newMask.equals(""))) {
				stringTemplate.append(crlf);
				stringTemplate.append(includeString);
			}
		}

		String updatedContent = stringTemplate.toString();

		String backupContent = flUtil.getInputFileAsString(inFile).toString();
		if (updatedContent.equals(backupContent)) {
			System.out
					.println("##########Generated content is exactly the same as in existing file, skip only:"
							+ outputFile);
			return;
		}
		File outFile = new File(outputFile);
		Functions.createDir(outFile);
		BufferedWriter outputWriter = new BufferedWriter(
				new OutputStreamWriter(new FileOutputStream(outFile), "UTF-8"));
		outputWriter.write(updatedContent);
		outputWriter.flush();
		outputWriter.close();

		System.out.println("Class "
				+ srcName
				+ "..NoParse File: "
				+ outputFile
				+ (ApplicationProperties.removeCode ? " code block removed!"
						: " generated/updated!"));
	}

	private void generateNoParseFiles(VelocityContext context) throws Exception {
		SqlTable sqlTable = (SqlTable) context.get("sqlTable");
		String srcName = Functions.makeClassName(sqlTable.getEntityName());

		Properties noParseList = Functions.extractProperties(this.properties,
				"NoParse");
		if (noParseList.size() == 0)
			return;
		Enumeration enums = noParseList.elements();
		while (enums.hasMoreElements()) {
			String embeddedParms = (String) enums.nextElement();
			processNoParseTemplate(context, srcName, embeddedParms);
		}
	}

	public static FileNameResolver getFileNameResolver() {
		return fileNameResolver;
	}

	public static FileLocationResolver getFileResolver() {
		return fileResolver;
	}

	public static PackageNameResolver getPackageResolver() {
		return packageResolver;
	}
}