package com.codegen.common;

import com.codegen.db.Dbconn;

public class ThreadContext extends ApplicationObject {
	private static ThreadLocal threadContext = null;
	private ApplicationProperties applicationProperties = null;
	private ListHashtable requestProperties = null;
	private Dbconn dbconn = null;

	private ThreadContext() {
		this.requestProperties = new ListHashtable();

		this.applicationProperties = new ApplicationProperties();

		this.dbconn = new Dbconn();
		try {
			this.dbconn.connect();
		} catch (Exception e) {
			throw new RuntimeException("Error connecting to database: "
					+ e.getMessage());
		}
	}

	public static synchronized ThreadContext getCurrentContext() {
		if (getThreadContext().get() == null) {
			ThreadContext aContext = new ThreadContext();
			threadContext.set(aContext);
		}
		return (ThreadContext) getThreadContext().get();
	}

	public ApplicationProperties getApplicationProperties() {
		return this.applicationProperties;
	}

	public void terminate(boolean commit) {
		getCurrentContext().getDbconn().closeconn(commit);
		getThreadContext().set(null);
	}

	public void commit() {
		terminate(true);
	}

	public void rollback() {
		terminate(false);
	}

	public Dbconn getDbconn() {
		return this.dbconn;
	}

	private static ThreadLocal getThreadContext() {
		if (threadContext == null) {
			threadContext = new ThreadLocal();
		}
		return threadContext;
	}

	public ListHashtable getRequestProperties() {
		return this.requestProperties;
	}

	public static void setRequestProperties(Object key, Object value) {
		getCurrentContext().getRequestProperties().put(key, value);
	}

	public static String getRequestPropertyAsString(String key) {
		return (String) getCurrentContext().getRequestProperties().get(key);
	}
}