package com.codegen.db;

import com.codegen.common.ApplicationProperties;
import com.codegen.common.Functions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.StringTokenizer;
/**
 * 将要产生源代码的表示列表
 * @author csx
 *
 */
public class CsvTableList extends TableList {
	public CsvTableList(String csvFile) {
		initFromCsvFile(csvFile);
	}

	private void addToList(String tb, String entity, String col, String attrib,
			String type, String nulltxt, String pkey, String fkey) {
		SqlTable tableObject = (SqlTable) this.tableList.get(tb);

		if (tableObject == null) {
			String schema = ApplicationProperties.getDbSchema();
			tableObject = new SqlTable(tb, schema, entity, false, false);
			this.tableList.put(tb, tableObject);
		}

		boolean nullable = !Functions.hasMask(nulltxt, "NOT");
		boolean withDefault = nullable;
		boolean isKey = Functions.hasMask(pkey, "Yes");

		int colsize = 0;
		int digits = 0;
		short coltype = 0;
		String coltypname = type;
		if (type.indexOf("(") > 0) {
			StringTokenizer tline = new StringTokenizer(type, ",()");
			coltypname = tline.nextToken().trim();
			colsize = new Integer(tline.nextToken().trim()).intValue();
			if (tline.hasMoreTokens()) {
				digits = new Integer(tline.nextToken().trim()).intValue();
			}
		}

		SqlColumn newColumn = new SqlColumn(col, attrib, coltype, colsize,
				digits, coltypname, nullable, withDefault, null);
		newColumn.setKey(isKey);
		tableObject.addColumn(newColumn);
		if (isKey)
			tableObject.getPrimaryKeys().add(newColumn);
	}

	private Hashtable initFromCsvFile(String rptFile) {
		initTableList();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream(rptFile)));
			String line = in.readLine();

			line = in.readLine();

			while ((line != null) && (!line.equals(eofstr))) {
				parseRptLine(line, this.tableList);
				line = in.readLine();
			}

			in.close();
		} catch (Exception e) {
			System.out.println("Error accessing file: " + rptFile + crlf + e);
			System.exit(1);
		}

		return this.tableList;
	}

	public Hashtable getTableList() {
		return this.tableList;
	}

	private void parseRptLine(String newLine, Hashtable tableList)
			throws Exception {
		StringTokenizer tline = new StringTokenizer(newLine, ",");
		String tableName = "";
		String columnName = "";
		String type = "";
		String nulltxt = "";
		String entity = "";
		String attrib = "";
		String pkey = "No";
		String fkey = "No";
		try {
			if (tline.hasMoreTokens()) {
				tableName = tline.nextToken().trim();
				columnName = tline.nextToken().trim();
				type = tline.nextToken().trim();
				nulltxt = tline.nextToken().trim();
				if (nulltxt.indexOf("NULL") < 0) {
					type = type + "," + nulltxt;
					nulltxt = tline.nextToken().trim();
				}
				if (tline.hasMoreTokens())
					entity = tline.nextToken().trim();
				if (tline.hasMoreTokens())
					attrib = tline.nextToken().trim();
				if (tline.hasMoreTokens())
					pkey = tline.nextToken().trim();
				if (tline.hasMoreTokens()) {
					fkey = tline.nextToken().trim();
				}
				addToList(tableName, entity, columnName, attrib, type, nulltxt,
						pkey, fkey);
			}
		} catch (Exception e) {
			throw new Exception("Cannot parse this line From CSV file"
					+ newLine);
		}
	}
}