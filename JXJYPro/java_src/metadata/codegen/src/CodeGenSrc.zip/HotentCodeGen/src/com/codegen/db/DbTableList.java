package com.codegen.db;

import com.codegen.common.ApplicationProperties;
import com.codegen.common.ThreadContext;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 * 数据库表列表
 * @author csx
 *
 */
public class DbTableList extends TableList {
	public DbTableList() throws SQLException {
		initFromDb();
	}

	private void initFromDb() throws SQLException {
		initTableList();

		DatabaseMetaData dbmd = ThreadContext.getCurrentContext().getDbconn().getConn().getMetaData();
		String table_type = "TABLE";
		String[] tableTypes = { table_type };
		String schema = ApplicationProperties.getDbSchema();
		//从某一数据库中获取所有表
		ResultSet tables = dbmd.getTables(null, schema, "%", tableTypes);
		int numTables = 0;

		while (tables.next()) {
			String table = tables.getString("TABLE_NAME");
			String type = tables.getString("TABLE_TYPE");
			if (type.equals(table_type)) {
				SqlTable aTable = new SqlTable(table, schema);
				getTableList().put(table, aTable);
				numTables++;
			}
		}

		tables.close();
	}
}