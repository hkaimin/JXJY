package com.codegen.db;

import com.codegen.common.ApplicationObject;
import com.codegen.common.ApplicationProperties;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 * 数据库连接对象,用于读取数据库配置的信息
 * @author csx
 *
 */
public class Dbconn extends ApplicationObject {
	private Connection conn = null;
	private String dbuserid;
	private String dbpasswd;
	private String jdbcDriver;
	private String dbUrl;
	private String errormsg;
	/**
	 * 从配置文件中构建连接
	 */
	public Dbconn() {
		this.jdbcDriver = ApplicationProperties.getJdbcDriver();
		this.dbUrl = ApplicationProperties.getDbUrl();
		this.dbuserid = ApplicationProperties.getDbUserid();
		this.dbpasswd = ApplicationProperties.getDbPasswd();
		this.errormsg = "";
		this.conn = null;
	}
	/**
	 * 关闭连接
	 * @param commit
	 */
	public void closeconn(boolean commit) {
		try {
			if (commit)
				commit();
			else {
				rollback();
			}
			if (this.conn != null)
				this.conn.close();
			this.conn = null;
		} catch (Exception e) {
			this.errormsg = ("Close connect Sqlerror to " + this.dbUrl + " " + e.toString());
			System.out.println(this.errormsg);
			e.printStackTrace();
		}
	}
	/**
	 * 提交事务
	 */
	public void commit() {
		try {
			if (this.conn != null)
				this.conn.commit();
		} catch (Exception e) {
			this.errormsg = ("Commit Sqlerror to " + this.dbUrl + " " + e
					.toString());
			System.out.println(this.errormsg);
			e.printStackTrace();
		}
	}
	/**
	 * 连接数据库
	 */
	public void connect() {
		try {
			if (this.conn != null)closeconn(true);
			Class.forName(this.jdbcDriver);
			if (((this.dbuserid.equals("") ? 0 : 1) & (this.dbpasswd.equals("") ? 0: 1)) != 0)
				this.conn = DriverManager.getConnection(this.dbUrl,this.dbuserid, this.dbpasswd);
			else {
				this.conn = DriverManager.getConnection(this.dbUrl);
			}
			this.conn.setAutoCommit(false);
		} catch (Exception e) {
			this.conn = null;
			this.errormsg = ("SqlError in creating connection to " + this.dbUrl+ " " + e.toString());
			System.out.println(this.errormsg);
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	/**
	 * 数据库Rollback
	 */
	public void rollback() {
		try {
			if (this.conn != null)
				this.conn.rollback();
		} catch (Exception e) {
			this.errormsg = ("Rollback Sqlerror to " + this.dbUrl + " " + e
					.toString());
			System.out.println(this.errormsg);
			e.printStackTrace();
		}
	}

	public Connection getConn() {
		if (this.conn == null) {
			connect();
		}
		return this.conn;
	}
}