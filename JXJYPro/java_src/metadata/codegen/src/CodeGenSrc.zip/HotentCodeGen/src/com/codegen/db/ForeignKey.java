package com.codegen.db;

import com.codegen.common.ApplicationObject;
import com.codegen.common.ApplicationProperties;
import com.codegen.common.ListHashtable;

import java.util.List;
/**
 * 获取某一的表外键信息
 * @author csx
 *
 */
public class ForeignKey extends ApplicationObject {
	protected String relationShip = null;
	protected String firstRelation = null;
	protected String secondRelation = null;
	protected SqlTable parentTable;
	protected String tableName;
	protected ListHashtable columns;
	protected ListHashtable parentColumns;

	public ForeignKey(SqlTable aTable, String tblName) {
		this.parentTable = aTable;
		this.tableName = tblName;
		this.columns = new ListHashtable();
		this.parentColumns = new ListHashtable();
	}

	public String getTableName() {
		return this.tableName;
	}

	public String getParentTableName() {
		return this.parentTable.getTable();
	}

	public void addColumn(String col, String parentCol, Integer seq) {
		this.columns.put(seq, col);
		this.parentColumns.put(seq, parentCol);
	}

	public String getColumn(String parentCol) {
		Object key = this.parentColumns.getKeyForValue(parentCol);
		String col = (String) this.columns.get(key);

		return col;
	}

	public ListHashtable getColumns() {
		return this.columns;
	}

	private void initRelationship() {
		this.firstRelation = "";
		this.secondRelation = "";
		SqlTable foreignTable = (SqlTable) ApplicationProperties.getSqlTables()
				.get(this.tableName);
		List parentPrimaryKeys = this.parentTable.getPrimaryKeys();
		List foreignPrimaryKeys = foreignTable.getPrimaryKeys();

		if (hasAllPrimaryKeys(parentPrimaryKeys, this.parentColumns))
			this.firstRelation = "one";
		else {
			this.firstRelation = "many";
		}
		if (hasAllPrimaryKeys(foreignPrimaryKeys, this.columns))
			this.secondRelation = "one";
		else {
			this.secondRelation = "many";
		}
		this.relationShip = (this.firstRelation + "-to-" + this.secondRelation);
	}

	private boolean hasAllPrimaryKeys(List pkeys, ListHashtable cols) {
		boolean hasAll = true;

		int numKeys = pkeys.size();
		if (numKeys != cols.size()) {
			return false;
		}
		for (int i = 0; i < numKeys; i++) {
			SqlColumn col = (SqlColumn) pkeys.get(i);
			String colname = col.getColname();
			if (!cols.contains(colname)) {
				return false;
			}
		}
		return hasAll;
	}

	public boolean isParentColumnsFromPrimaryKey() {
		boolean isFrom = true;
		List keys = this.parentTable.getPrimaryKeys();
		int numKeys = getParentColumns().size();
		for (int i = 0; i < numKeys; i++) {
			String pcol = (String) getParentColumns().getOrderedValue(i);
			if (!primaryKeyHasColumn(pcol)) {
				isFrom = false;
				break;
			}
		}
		return isFrom;
	}

	private boolean primaryKeyHasColumn(String aColumn) {
		boolean isFound = false;
		int numKeys = this.parentTable.getPrimaryKeys().size();
		for (int i = 0; i < numKeys; i++) {
			SqlColumn sqlCol = this.parentTable.getPrimaryKey(i);
			String colname = sqlCol.getColname();
			if (colname.equals(aColumn)) {
				isFound = true;
				break;
			}
		}
		return isFound;
	}

	public boolean getHasImportedKeyColumn(String aColumn) {
		boolean isFound = false;
		List cols = getColumns().getOrderedValues();
		int numCols = cols.size();
		for (int i = 0; i < numCols; i++) {
			String col = (String) cols.get(i);
			if (col.equals(aColumn)) {
				isFound = true;
				break;
			}
		}
		return isFound;
	}

	public String getFirstRelation() {
		if (this.firstRelation == null)
			initRelationship();
		return this.firstRelation;
	}

	public SqlTable getSqlTable() {
		SqlTable table = (SqlTable) ApplicationProperties.getSqlTables().get(
				this.tableName);
		return table;
	}

	public SqlTable getParentTable() {
		return this.parentTable;
	}

	public String getRelationShip() {
		if (this.relationShip == null)
			initRelationship();
		return this.relationShip;
	}

	public String getSecondRelation() {
		if (this.secondRelation == null)
			initRelationship();
		return this.secondRelation;
	}

	public ListHashtable getParentColumns() {
		return this.parentColumns;
	}

	public boolean getHasImportedKeyParentColumn(String aColumn) {
		boolean isFound = false;
		List cols = getParentColumns().getOrderedValues();
		int numCols = cols.size();
		for (int i = 0; i < numCols; i++) {
			String col = (String) cols.get(i);
			if (col.equals(aColumn)) {
				isFound = true;
				break;
			}
		}
		return isFound;
	}
}