package com.codegen.db;

import com.codegen.common.ApplicationObject;
import com.codegen.common.ApplicationProperties;
import com.codegen.common.FieldTypeResolver;
import com.codegen.common.Functions;
/**
 * 表的列
 * @author csx
 *
 */
public class SqlColumn extends ApplicationObject {
	private String colname;
	private String businessAttributeName;
	private short coltype;
	private String attType = null;
	private int colsize;
	private int digits;
	private String coltypname;
	private String remarks;
	private boolean nullable = false;

	private boolean withDefault = false;

	private boolean key = false;

	public SqlColumn(String colname, String attName, short coltype,
			int colsize, int digits, String coltypname, boolean nullable,
			boolean withDefault, String remarks) {
		this.colname = colname;

		if ((attName == null) || (attName.equals("")))
			this.businessAttributeName = colname;
		else {
			this.businessAttributeName = attName;
		}
		this.coltype = coltype;
		this.colsize = colsize;
		this.coltypname = coltypname;
		this.digits = digits;
		this.nullable = nullable;
		this.withDefault = withDefault;
		this.remarks = remarks;
		initAttType();
	}

	public boolean isKey() {
		return this.key;
	}

	public boolean isVersion() {
		return getColname().equalsIgnoreCase("version");
	}

	public void setKey(boolean key) {
		this.key = key;
	}

	public String getColname() {
		return this.colname;
	}

	public String getAttType() {
		if (this.attType == null) {
			initAttType();
		}
		return this.attType;
	}

	private void initAttType() {
		this.attType = "String";

		if (Functions.hasMask(this.coltypname, "date")) {
			this.attType = "java.util.Date";
		} else if (Functions.hasMask(this.coltypname, "NUMBER")) {
			if (this.digits > 0)
				this.attType = "java.math.BigDecimal";
			else if (this.colsize == 10)
				this.attType = "Integer";
			else if (this.colsize == 5)
				this.attType = "Short";
			else if (this.colsize > 12) {
				this.attType = "Long";
			}

		} else if (Functions.hasMask(this.coltypname, "decimal")) {
			this.attType = "java.math.BigDecimal";
		} else if (Functions.hasMask(this.coltypname, "timestamp")) {
			this.attType = "java.sql.Timestamp";
		} else if (Functions.hasMask(this.coltypname, "small")) {
			this.attType = "Short";
		} else if (Functions.hasMask(this.coltypname, "bigint")) {
			this.attType = "Long";
		} else if (Functions.hasMask(this.coltypname, "int")) {
			this.attType = "Integer";
		} else if (Functions.hasMask(this.coltypname, "double")) {
			this.attType = "Double";
		} else if (Functions.hasMask(this.coltypname, "Float"))
			this.attType = "Float";
	}

	public String getHibernateType() {
		if (isKey()) {
			return "id";
		}
		return "property";
	}

	public String getNotNullable() {
		if (!this.nullable) {
			return "true";
		}
		return "false";
	}

	public String getNullable() {
		if (!this.nullable) {
			return "false";
		}
		return "true";
	}

	public String getAttName() {
//		if("True".equals(ApplicationProperties.getUseCaseSensitiveNames())){
//			return this.colname;
//		}
		return Functions.makeVarName(this.colname);
	}

	public String getAttNameUC() {
		String tmp = getAttName();
		return Functions.makeFirstLetterUpperCase(tmp);
	}

	public String getColnameLC() {
		return this.colname.toLowerCase();
	}

	public boolean isStringColumn() {
		return Functions.hasMask(getAttType(), "String");
	}

	public boolean isDecimal() {
		return Functions.hasMask(getAttType(), "Decimal");
	}

	public boolean isType(String aType) {
		return Functions.hasMask(getAttType(), aType);
	}

	public String getDecimalMask() {
		String mask = "";
		if (!isDecimal()) {
			return mask;
		}
		mask = Functions.getFmtString(getBusinessAttributeVar(), getColsize(),
				getDigits());
		return mask;
	}

	public boolean isRequired() {
		if (this.colname.equalsIgnoreCase("version"))
			return false;
		if (isKey()) {
			return true;
		}
		return !isNullable();
	}

	public int getColsize() {
		return this.colsize;
	}

	public short getColtype() {
		return this.coltype;
	}

	public String getJavaType() {
		String javaType = getAttType();
		if (javaType.indexOf(".") <= 0) {
			javaType = "java.lang." + getAttType();
		}
		return javaType;
	}

	public String getColtypname() {
		return this.coltypname;
	}

	public int getDigits() {
		return this.digits;
	}

	public boolean isNullable() {
		return this.nullable;
	}

	public boolean isWithDefault() {
		return this.withDefault;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public String getBusinessAttributeName() {
		return this.businessAttributeName;
	}

	public String getResolvedAttType() {
		String typ = getAttType();
		String resolvedType = FieldTypeResolver.getResolver().getPropertyValue(
				getBusinessAttributeVar(), typ);
		return resolvedType;
	}

	public String getBusinessAttributeVar() {
		return Functions.makeVarName(this.businessAttributeName);
	}

	public String getBusinessAttribute() {
		return Functions.makeClassName(this.businessAttributeName);
	}
}