package com.codegen.db;

import com.codegen.common.ApplicationObject;
import com.codegen.common.ApplicationProperties;
import com.codegen.common.EzwGen;
import com.codegen.common.Functions;
import com.codegen.common.ListHashtable;
import com.codegen.common.ThreadContext;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
/**
 * 表
 * @author csx
 *
 */
public class SqlTable extends ApplicationObject {
	public static final String COLUMN_NAME = "COLUMN_NAME";
	public static final String DELETE_RULE = "DELETE_RULE";
	public static final String FKCOLUMN_NAME = "FKCOLUMN_NAME";
	public static final String FKTABLE_NAME = "FKTABLE_NAME";
	public static final String KEY_SEQ = "KEY_SEQ";
	public static final String PK_NAME = "PK_NAME";
	public static final String PKCOLUMN_NAME = "PKCOLUMN_NAME";
	public static final String PKTABLE_NAME = "PKTABLE_NAME";
	public static final String UPDATE_RULE = "UPDATE_RULE";
	protected HashMap allColumns;
	protected String entityName;
	protected String entityNameFromTableName;
	protected ForeignKeys exportedKeys = null;

	protected boolean generated = false;

	protected boolean hasDeleted = false;

	protected Boolean hasTestableColumn = null;

	protected boolean hasVersion = false;

	protected ForeignKeys importedKeys = null;
	protected List primaryKeys;
	String remarks;
	protected String schema;
	protected List sqlColumns;
	protected String table;
	protected SqlColumn testableColumn = null;
	protected List typeList;

	public static String parse(String all) {
		String comment = null;
		int index = all.indexOf("COMMENT='");
		if (index < 0) {
			return "";
		}
		comment = all.substring(index + 9, all.length() - 1);
		return comment;
	}

	public SqlTable(String tbl, String sch) {
		this(tbl, sch, tbl, true, true);
	}

	public SqlTable(String tbl, String sch, boolean isCaseSensitive,
			String pojoName) {
		this(tbl, sch, pojoName, isCaseSensitive, true);
	}

	public SqlTable(String tbl, String sch, String entity,
			boolean isCaseSensitive, boolean fromDb) {
		String originalTableName = tbl;
		if (!isCaseSensitive) {
			tbl = tbl.trim().toUpperCase();
			sch = sch.trim().toUpperCase();
		}
		this.table = tbl.trim();
		this.schema = sch.trim();

		this.entityNameFromTableName = tbl.trim();

		if (this.entityName != null)
			this.entityName = entity.trim();
		else {
			this.entityName = null;
		}

		initHolders();
		if (fromDb) {
			getTableInfoFromDatabase();
		}

		ApplicationProperties.getSqlTables().put(originalTableName, this);
		List eKeys = getExportedKeys().getAssociatedTables().getOrderedKeys();
		List iKeys = getImportedKeys().getAssociatedTables().getOrderedKeys();
		initForeignKeyTables(eKeys, sch, isCaseSensitive, fromDb);
		initForeignKeyTables(iKeys, sch, isCaseSensitive, fromDb);
	}

	public void addColumn(SqlColumn newColumn) {
		this.allColumns.put(newColumn.getColname(), newColumn);
		this.sqlColumns.add(newColumn);
		if (newColumn.getColname().equalsIgnoreCase("version"))
			this.hasVersion = true;
		else if (newColumn.getColname().equalsIgnoreCase("deleted")) {
			this.hasDeleted = true;
		}
		String attType = newColumn.getAttType();
		if ((Functions.hasMask(attType, "java."))
				&& (!this.typeList.contains(attType)))
			this.typeList.add(attType);
	}

	private void determineTestableColumn() {
		this.hasTestableColumn = new Boolean(false);
		int numColumns = getSqlColumns().size();
		for (int i = 0; i < numColumns; i++) {
			SqlColumn newColumn = (SqlColumn) getSqlColumns().get(i);
			if (!newColumn.isKey()) {
				String coltypname = newColumn.getColtypname();
				if (Functions.hasMask(coltypname, "char")) {
					this.hasTestableColumn = new Boolean(true);
					this.testableColumn = newColumn;
					break;
				}
			}
		}
	}

	public HashMap getAllColumns() {
		return this.allColumns;
	}

	public String getEntityName() {
		if (this.entityName == null) {
			ListHashtable pojoNames = ApplicationProperties.getPojoNames();
			if (pojoNames.containsKey(this.table)) {
				return (String) pojoNames.get(this.entityNameFromTableName);
			}
			return this.entityNameFromTableName;
		}

		return this.entityName;
	}

	public String getEntityNameFromTableName() {
		return this.entityNameFromTableName;
	}

	public ForeignKeys getExportedKeys() {
		if (this.exportedKeys == null) {
			this.exportedKeys = new ForeignKeys(this);
		}
		return this.exportedKeys;
	}

	private void getExportedKeys(DatabaseMetaData dbmd) throws SQLException {
		ResultSet fkeys=null;
		if(ApplicationProperties.getJdbcDriver().indexOf("SQLServerDriver")!=-1){
			fkeys = dbmd.getExportedKeys(this.schema, null, this.table);
		}else{		
			fkeys = dbmd.getExportedKeys(this.schema,dbmd.getUserName(),this.table);
		}
		//ResultSet fkeys = dbmd.getExportedKeys(null, this.schema, this.table);

		while (fkeys.next()) {
			String pktable = fkeys.getString("PKTABLE_NAME");
			String pkcol = fkeys.getString("PKCOLUMN_NAME");
			String fktable = fkeys.getString("FKTABLE_NAME");
			String fkcol = fkeys.getString("FKCOLUMN_NAME");
			String seq = fkeys.getString("KEY_SEQ");
			Integer iseq = new Integer(seq);
			getExportedKeys().addForeignKey(fktable, fkcol, pkcol, iseq);
		}
		fkeys.close();
	}

	public EzwGen getEzwGen() {
		return EzwGen.getEzwGen(this);
	}

	private void getFirstUniqueIndex(DatabaseMetaData dbmd) {
		try {
			ListHashtable pk = new ListHashtable();
			
			ResultSet indexes = null;
			
			if(ApplicationProperties.getJdbcDriver().indexOf("SQLServerDriver")!=-1){
				indexes=dbmd.getIndexInfo(this.schema, null,this.table, false, false);
			}else{		
				indexes=dbmd.getIndexInfo(this.schema, dbmd.getUserName(),this.table, false, false);
			}
			
			int numindexes = 0;
			int indcolcnt = 0;

			String NON_UNIQUE = "NON_UNIQUE";
			String INDEX_QUALIFIER = "INDEX_QUALIFIER";
			String INDEX_NAME = "INDEX_NAME";
			String INDCOL_NAME = "COLUMN_NAME";
			String ASC_OR_DESC = "ASC_OR_DESC";
			String INDEX_TYPE = "TYPE";

			String cindstr = "";
			String indline = "";
			String index = "";
			String previndex = "";
			String ascendstr = "";
			String indstring = "";
			boolean found = false;
			while (indexes.next()) {
				String indname = indexes.getString(INDEX_NAME);
				if (indname != null) {
					String indqual = indexes.getString(INDEX_QUALIFIER);
					String asc = indexes.getString(ASC_OR_DESC);
					boolean nonunique = indexes.getBoolean(NON_UNIQUE);
					String colname = indexes.getString(INDCOL_NAME);
					String seq = indexes.getString("KEY_SEQ");
					Integer iseq = new Integer(seq);
					previndex = index;
					index = indqual.trim() + "." + indname.trim();
					if ((!previndex.equals(index)) && (!previndex.equals(""))
							&& (found)) {
						break;
					}
					if (!nonunique) {
						found = true;
					}
					if (found) {
						String keystr = colname;
						SqlColumn x = (SqlColumn) this.allColumns.get(keystr);
						x.setKey(true);
						pk.put(iseq, x);
					}
				}
			}

			indexes.close();
			this.primaryKeys = pk.getOrderedValues();
		} catch (Exception e) {
			throw new RuntimeException("Error getting first unique index for "
					+ this.table + " : " + e.getMessage());
		}
	}

	public boolean getHasCompositeKey() {
		return getPrimaryKeys().size() > 1;
	}

	public boolean getHasDeleted() {
		return this.hasDeleted;
	}

	public boolean getHasGeneratedKey() {
		boolean isGenerated = ApplicationProperties.isGeneratedKey(this);
		return isGenerated;
	}

	public boolean getHasImportedKeyColumn(String aColumn) {
		boolean isFound = getImportedKeys().getHasImportedKeyColumn(aColumn);
		return isFound;
	}

	public boolean getHasImportedKeyParentColumn(String aColumn) {
		boolean isFound = getImportedKeys().getHasImportedKeyParentColumn(
				aColumn);
		return isFound;
	}

	public boolean getHasSingleKey() {
		return getPrimaryKeys().size() == 1;
	}

	public boolean getHasTestableColumn() {
		if (this.hasTestableColumn == null) {
			determineTestableColumn();
		}

		return this.hasTestableColumn.booleanValue();
	}

	public boolean getHasVersion() {
		return this.hasVersion;
	}

	public ForeignKey getImportedKeyParentColumn(String aColumn) {
		ForeignKey aKey = getImportedKeys().getImportedKeyParentColumn(aColumn);
		return aKey;
	}

	public ForeignKeys getImportedKeys() {
		if (this.importedKeys == null) {
			this.importedKeys = new ForeignKeys(this);
		}
		return this.importedKeys;
	}

	private void getImportedKeys(DatabaseMetaData dbmd) throws SQLException {
		//SqlServer2005
		ResultSet fkeys=null;
		if(ApplicationProperties.getJdbcDriver().indexOf("SQLServerDriver")!=-1){
			fkeys = dbmd.getImportedKeys(this.schema, null, this.table);
		}else{		
			fkeys = dbmd.getImportedKeys(this.schema,dbmd.getUserName(),this.table);
		}

		while (fkeys.next()) {
			String pktable = fkeys.getString("PKTABLE_NAME");
			String pkcol = fkeys.getString("PKCOLUMN_NAME");
			String fktable = fkeys.getString("FKTABLE_NAME");
			String fkcol = fkeys.getString("FKCOLUMN_NAME");
			String seq = fkeys.getString("KEY_SEQ");
			Integer iseq = new Integer(seq);
			getImportedKeys().addForeignKey(pktable, pkcol, fkcol, iseq);
		}
		fkeys.close();
	}

	private void getIndexInfo(DatabaseMetaData dbmd) throws SQLException {
		ListHashtable pk = new ListHashtable();

		ResultSet pkeys = dbmd.getPrimaryKeys(null, null, this.table);

		while (pkeys.next()) {
			String pkeystr = pkeys.getString("COLUMN_NAME");
			String seq = pkeys.getString("KEY_SEQ");
			Integer iseq = new Integer(seq);
			SqlColumn x = (SqlColumn) this.allColumns.get(pkeystr);
			if(x!=null){
				x.setKey(true);
				pk.put(iseq, x);
			}
		}
		pkeys.close();
		this.primaryKeys = pk.getOrderedValues();

		if (this.primaryKeys.size() == 0)
			getFirstUniqueIndex(dbmd);
	}

	public SqlColumn getPrimaryKey(int i) {
		if (i > getPrimaryKeys().size() - 1) {
			return null;
		}
		return (SqlColumn) getPrimaryKeys().get(i);
	}

	public List getPrimaryKeys() {
		return this.primaryKeys;
	}

	public String getRemarks() {
		if (this.remarks == null) {
			if (ApplicationProperties.getJdbcDriver().indexOf("mysql") == -1){
				return "";
			}
			
			try {
				Statement stmt = ThreadContext.getCurrentContext().getDbconn()
						.getConn().createStatement();
				ResultSet rs = stmt.executeQuery("SHOW CREATE TABLE "
						+ getTable());
				if ((rs != null) && (rs.next())) {
					String create = rs.getString(2);
					this.remarks = parse(create);
				}

				rs.close();
				stmt.close();

				if ((this.remarks == null) || ("".equals(this.remarks)))
					this.remarks = "TODO: add class/table comments";
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return this.remarks;
	}

	public String getSchema() {
		return this.schema;
	}

	public List getSqlColumns() {
		return this.sqlColumns;
	}

	public String getTable() {
		return this.table;
	}

	private boolean getTableInfoFromDatabase() {
		initHolders();
		try {
			DatabaseMetaData dbmd = ThreadContext.getCurrentContext().getDbconn().getConn().getMetaData();
			ResultSet columns=null;
//			ResultSet columns = dbmd.getColumns(null, this.schema, this.table,
//					null);
			//oracle 10g or mysql
//			ResultSet columns = dbmd.getColumns(null,dbmd.getUserName(),this.table,null);
			
			//SqlServer2005
			if(ApplicationProperties.getJdbcDriver().indexOf("SQLServerDriver")!=-1){
				columns= dbmd.getColumns(this.schema,null,this.table,null);
			}else{
				columns = dbmd.getColumns(this.schema,dbmd.getUserName(),this.table,null);
			}
			
			int colcount = 0;

			String COLUMN_NAME = "COLUMN_NAME";
			String DATA_TYPE = "DATA_TYPE";
			String TYPE_NAME = "TYPE_NAME";
			String COLUMN_SIZE = "COLUMN_SIZE";
			String DECIMAL_DIGITS = "DECIMAL_DIGITS";
			String NULLABLE = "NULLABLE";
			String COLUMN_DEF = "COLUMN_DEF";

			while (columns.next()) {
				colcount++;
				String colname = columns.getString(COLUMN_NAME);
				//System.out.println("column name:=============" + colname);
				short coltype = columns.getShort(DATA_TYPE);
				int colsize = columns.getInt(COLUMN_SIZE);
				int digits = 0;
				String coltypname = columns.getString(TYPE_NAME).toUpperCase();
				boolean nullable = false;
				boolean withDefault = true;

				if ((coltype == 3) || (coltype == 2)) {
					digits = columns.getInt(DECIMAL_DIGITS);
				}

				if (columns.getInt(NULLABLE) == 1)
					nullable = true;
				else {
					nullable = false;
				}
				withDefault = columns.getString(COLUMN_DEF) != null;
				String colRemarks = columns.getString("REMARKS");

				SqlColumn newColumn = new SqlColumn(colname, colname, coltype,
						colsize, digits, coltypname, nullable, withDefault,
						colRemarks);
				addColumn(newColumn);
			}

			columns.close();

			getIndexInfo(dbmd);

			getImportedKeys(dbmd);
			getExportedKeys(dbmd);

			return colcount > 0;
		} catch (SQLException e) {
			System.out
					.println("Exception encountered in getTableInfo(): + e.getMessage():"+e.getMessage());
		}
		throw new RuntimeException("Error throws by SqlTable");
	}

	public SqlColumn getTestableColumn() {
		return this.testableColumn;
	}

	public List getTypeList() {
		return this.typeList;
	}

	private void initForeignKeyTables(List ftable, String sch,
			boolean isCaseSensitive, boolean fromDb) {
		ListHashtable sqlTables = ApplicationProperties.getSqlTables();
		// loop through all foreign keys and init foreign key tables
		int numFkeys = ftable.size();
		for (int i = 0; i < numFkeys; i++) {
			String ftbl = (String) ftable.get(i);
			if (!sqlTables.containsKey(ftbl)) {
				SqlTable foreign = new SqlTable(ftbl, sch, ftbl,
						isCaseSensitive, fromDb);
			}
		}
	}

	private void initHolders() {
		this.sqlColumns = new ArrayList();
		this.primaryKeys = new ArrayList();
		this.allColumns = new HashMap();
		this.typeList = new ArrayList();
	}

	public boolean isGenerated() {
		return this.generated;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public void setGenerated(boolean generated) {
		this.generated = generated;
	}
}