package com.codegen.db;

import com.codegen.common.ApplicationObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
/**
 * 数据库中的所有表集合列表
 * @author csx
 *
 */
public class TableList extends ApplicationObject {
	public static String crlf = System.getProperties().getProperty(
			"line.separator");
	public static char[] eofchar = { '\032' };
	public static String eofstr = new String(eofchar);
	protected Hashtable tableList;

	protected void initTableList() {
		this.tableList = new Hashtable();
	}

	public Hashtable getTableList() {
		return this.tableList;
	}

	public List getSortedTableObjects() {
		List sortedObjects = new ArrayList();
		List nameList = getSortedTableNames();
		int numObjects = nameList.size();
		for (int i = 0; i < numObjects; i++) {
			String name = (String) nameList.get(i);
			sortedObjects.add(this.tableList.get(name));
		}
		return sortedObjects;
	}

	public List getSortedTableNames() {
		Enumeration names = this.tableList.keys();
		List nameList = new ArrayList();
		while (names.hasMoreElements()) {
			nameList.add(names.nextElement());
		}
		Collections.sort(nameList);
		return nameList;
	}
}