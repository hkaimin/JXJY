package com.codegen.runner;

import com.codegen.common.ApplicationProperties;
import com.codegen.common.FieldTypeResolver;
import com.codegen.common.FileLocationResolver;
import com.codegen.common.FileUtility;
import com.codegen.common.Functions;
import com.codegen.common.PackageNameResolver;
import com.codegen.common.StringUtil;
import com.codegen.common.TemplateProcessor;
import com.codegen.common.ThreadContext;
import com.codegen.db.CsvTableList;
import com.codegen.db.DbTableList;
import com.codegen.db.SqlTable;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import org.apache.velocity.VelocityContext;

public class CodeGenerator {
	private static CsvTableList csvTableList = null;

	public static void main(String[] args) throws Exception {
		int numArgs = args.length;

		if (numArgs < 1) {
			System.out.print("Syntax: Code Generator <tableName List> sys=hotent");
			System.exit(1);
		}

		String[] inputArgs = filter(args);

		initCsvTableList();
		Object[] tableNames;
		if (inputArgs[0].startsWith("@")) {
			FileUtility flUtil = new FileUtility();
			List tabList = flUtil
					.getInputFileAsArray(inputArgs[0].substring(1));
			tableNames = tabList.toArray();
			if (((String) tableNames[0]).indexOf("*") >= 0) {
				System.out.println("Generating all tables found in database.");
				tableNames = new DbTableList().getSortedTableNames().toArray();
			}
		} else if (inputArgs[0].indexOf("-") >= 0) {
			Vector tables = StringUtil.parseToVector(inputArgs[0], "-");
			tableNames = new String[tables.size()];
			tables.copyInto(tableNames);
		} else {
			tableNames = inputArgs;
		}
		String schema = ApplicationProperties.getDbSchema();
		String useCaseSensitiveNames = ApplicationProperties
				.getUseCaseSensitiveNames();

		boolean isCaseSensitive = (useCaseSensitiveNames != null)
				&& ((Functions.hasMask(useCaseSensitiveNames, "y"))
						|| (Functions.hasMask(useCaseSensitiveNames, "t")) || (Functions
						.hasMask(useCaseSensitiveNames, "1")));

		int numTables = tableNames.length;
		System.out.println("!!!!!!!! Generator Started for Framework: " + ApplicationProperties.framework + " !!!!!!!!!");
		for (int i = 0; i < numTables; i++) {
			String tabName = (String) tableNames[i];
			if ((tabName == null) || (tabName.equals(""))
					|| (tabName.startsWith("#")))
				continue;
			generateFilesForOneTable(tabName, schema, isCaseSensitive);
		}

		FieldTypeResolver.destroyResolver();
		FileLocationResolver.destroyResolver();
		PackageNameResolver.destroyResolver();
		ApplicationProperties.destroyProperties();
	}

	private static void generateFilesForOneTable(String tableName,
			String schema, boolean isCaseSensitive) throws Exception {
		SqlTable sqlTable = getSqlTable(tableName, schema, isCaseSensitive);

		generateFilesForSqlTable(sqlTable, schema, isCaseSensitive);
	}
	/**
	 * 为表按模板配置产生所有源文件
	 * @param sqlTable
	 * @param schema
	 * @param isCaseSensitive
	 * @throws Exception
	 */
	private static void generateFilesForSqlTable(SqlTable sqlTable,
			String schema, boolean isCaseSensitive) throws Exception {
		System.out.println("--------> Start Generation All Templates for Table:  " + sqlTable.getTable() + " <-----------");

		Functions commonFunctions = new Functions();
		VelocityContext context = new VelocityContext();
		context.put("sqlTable", sqlTable);
		context.put("utility", commonFunctions);
		ApplicationProperties appProperties = ThreadContext.getCurrentContext().getApplicationProperties();
		context.put("prop", appProperties);
		TemplateProcessor templateProcessor = new TemplateProcessor(ApplicationProperties.getProperties());
		templateProcessor.process(context);
		System.out.println("--------> End of Generation All Templates for Table: " + sqlTable.getTable() + " <-----------");
		System.out.println();
		System.out.println();
		sqlTable.setGenerated(true);
	}
	/**
	 * 获取初始化表
	 */
	public static void initCsvTableList() {
		String csvFile = ApplicationProperties.getProperty("csvFile");
		if (csvFile.equals(""))
			return;
		csvTableList = new CsvTableList(csvFile);
	}
	/**
	 * 根据参数过滤
	 * @param args
	 * @return
	 */
	private static String[] filter(String[] args) {
		Vector output = new Vector();

		int numArgs = args.length;
		for (int i = 0; i < numArgs; i++) {
			String arg = args[i];
			if (arg.toUpperCase().startsWith("SYS=")) {
				String frw = arg.substring(4).toLowerCase();
				ApplicationProperties.framework = frw;
			} else if (arg.toUpperCase().equals("FORCEDOVERWRITE=TRUE")) {
				ApplicationProperties.forcedOverwrite = true;
			} else if (arg.toUpperCase().equals("REMOVECODE=TRUE")) {
				ApplicationProperties.removeCode = true;
				System.out.println("removeCode is true");
			} else {
				System.out.println("DEBUG: Arguement for output:" + arg);
				output.addElement(arg);
			}
		}
		String[] outputArgs = new String[output.size()];
		output.copyInto(outputArgs);

		return outputArgs;
	}
	/**
	 * 取得表实体
	 * @param tableName 表名
	 * @param schema 数据库
	 * @param isCaseSensitive 大小敏感
	 * @return
	 */
	public static SqlTable getSqlTable(String tableName, String schema,boolean isCaseSensitive) {
		String pojoName = null;
		String[] fields = tableName.split("\\s+");
		if (fields.length == 2) {
			tableName = fields[0];
			pojoName = fields[1];
		}

		SqlTable sqlTable = null;
		if (csvTableList != null) {
			sqlTable = (SqlTable) csvTableList.getTableList().get(tableName);
		} else if (ApplicationProperties.getSqlTables().containsKey(tableName)) {
			sqlTable = (SqlTable) ApplicationProperties.getSqlTables().get(
					tableName);
			sqlTable.setEntityName(pojoName);
		} else {
			sqlTable = new SqlTable(tableName, schema, isCaseSensitive, pojoName);
		}

		return sqlTable;
	}
}