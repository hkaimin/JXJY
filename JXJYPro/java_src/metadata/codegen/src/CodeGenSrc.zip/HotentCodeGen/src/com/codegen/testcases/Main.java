package com.codegen.testcases;

import com.codegen.runner.CodeGenerator;

public class Main {
	public static void main(String[]args) throws Exception{
		
		System.out.println("codegen is start.......");
		String[]params={"@specifiedTables","sys=hotent","forcedOverwrite=true","removeCode=false"};
		
		CodeGenerator.main(params);
		
		System.out.println("codegne is end...........");
		
	}
}
