 package com.codegen.testcases;
 
 import com.codegen.common.ThreadContext;
import com.codegen.db.CsvTableList;

 import java.util.Hashtable;
import junit.framework.TestCase;
 
 public class TestCsvTableList extends TestCase
 {
   CsvTableList csvTableList = null;
 
   public static void main(String[] args)
   {
   }
 
   protected void setUp() throws Exception
   {
     super.setUp();
     this.csvTableList = new CsvTableList("d:\\workEclipse\\Generator\\sample.csv");
   }
 
   protected void tearDown()
     throws Exception
   {
     super.tearDown();
     this.csvTableList = null;
     ThreadContext.getCurrentContext().commit();
   }
 
   public void testCsvTableList() {
     assertNotNull(this.csvTableList.getTableList());
     assertTrue(this.csvTableList.getTableList().size() > 0);
     assertNotNull(this.csvTableList.getTableList().get("TSP_AUD_FL"));
   }
 }