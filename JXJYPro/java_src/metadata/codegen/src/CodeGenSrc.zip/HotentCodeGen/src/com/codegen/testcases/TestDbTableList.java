 package com.codegen.testcases;
 
 import com.codegen.common.ThreadContext;
import com.codegen.db.DbTableList;

 import java.util.Hashtable;
import junit.framework.TestCase;
 
 public class TestDbTableList extends TestCase
 {
   DbTableList dbTableList = null;
 
   public static void main(String[] args)
   {
   }
 
   protected void setUp() throws Exception
   {
     super.setUp();
     this.dbTableList = new DbTableList();
   }
 
   protected void tearDown()
     throws Exception
   {
     super.tearDown();
     this.dbTableList = null;
     ThreadContext.getCurrentContext().commit();
   }
 
   public void testDbTableList()
   {
     assertNotNull(this.dbTableList.getTableList());
     assertTrue(this.dbTableList.getTableList().size() > 0);
     assertNotNull(this.dbTableList.getTableList().get("client_info"));
     assertNotNull(this.dbTableList.getTableList().get("client_asset"));
   }
 }