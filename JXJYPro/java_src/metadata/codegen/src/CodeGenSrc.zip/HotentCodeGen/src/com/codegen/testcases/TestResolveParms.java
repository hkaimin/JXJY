 package com.codegen.testcases;
 
 import com.codegen.common.PropertiesResolver;

import java.io.PrintStream;
 
 public class TestResolveParms
 {
   public static void main(String[] args)
   {
     String test = "This is a test String with ${packagePrefix} testing of main";
     String retValue = PropertiesResolver.resolveParms(test);
     System.out.println("RetValue=" + retValue);
   }
 }