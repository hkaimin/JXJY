 package com.codegen.testcases;
 
 import com.codegen.common.ThreadContext;
import com.codegen.db.SqlColumn;
import com.codegen.db.SqlTable;

 import java.util.HashMap;
 import java.util.List;
import junit.framework.TestCase;
 
 public class TestSqlTable extends TestCase
 {
   SqlTable sqlTable = null;
 
   public static void main(String[] args)
   {
   }
 
   protected void setUp()
     throws Exception
   {
     super.setUp();
     this.sqlTable = new SqlTable("menu_item", "", false, "menu_item");
   }
 
   protected void tearDown()
     throws Exception
   {
     super.tearDown();
     this.sqlTable = null;
     ThreadContext.getCurrentContext().terminate(true);
   }
 
   public void testSqlTable()
   {
     assertEquals("MENU_ITEM", this.sqlTable.getTable());
     assertEquals("MENU_ITEM", this.sqlTable.getEntityName());
     assertEquals("", this.sqlTable.getSchema());
     assertTrue(this.sqlTable.getAllColumns().size() == 20);
     assertTrue(this.sqlTable.getPrimaryKeys().size() > 0);
     assertTrue(this.sqlTable.getPrimaryKey(0).isKey());
     assertTrue(this.sqlTable.getPrimaryKey(0).getColname().equalsIgnoreCase("MENU_ID"));
   }
 }