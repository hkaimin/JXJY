 package com.codegen.testcases;
 
 import com.codegen.common.ApplicationProperties;
import com.codegen.common.ListHashtable;
import com.codegen.common.ThreadContext;
import com.codegen.db.ForeignKey;
import com.codegen.db.ForeignKeys;
import com.codegen.db.SqlColumn;
import com.codegen.db.SqlTable;

 import java.io.PrintStream;
 import java.util.HashMap;
 import java.util.List;
import junit.framework.TestCase;
 
 public class TestSqlTableForeignKeys extends TestCase
 {
   SqlTable sqlTable = null;
 
   public static void main(String[] args)
   {
   }
 
   protected void setUp()
     throws Exception
   {
     super.setUp();
     this.sqlTable = new SqlTable("personal_finance", "", true, "");
   }
 
   protected void tearDown()
     throws Exception
   {
     super.tearDown();
     this.sqlTable = null;
     ThreadContext.getCurrentContext().terminate(true);
   }
 
   public void testSqlTableForeignKeys()
   {
     assertEquals("personal_finance", this.sqlTable.getTable());
     assertEquals("", this.sqlTable.getSchema());
     assertTrue(this.sqlTable.getAllColumns().size() == 6);
     assertTrue(this.sqlTable.getPrimaryKeys().size() == 3);
     assertTrue(this.sqlTable.getPrimaryKey(0).isKey());
     assertTrue(this.sqlTable.getImportedKeys().getAssociatedTables().size() == 2);
     ListHashtable tables = ApplicationProperties.getSqlTables();
     assertTrue(tables.containsKey("personal_finance"));
     assertTrue(tables.containsKey("person_info"));
     assertTrue(tables.containsKey("bank_info"));
     assertTrue(tables.containsKey("financial_institutions"));
     ForeignKeys fkeys = this.sqlTable.getImportedKeys();
     ForeignKey fkey = fkeys.getAssociatedTable("person_info");
     assertTrue(fkey.getColumns().size() == 2);
     System.out.println("Personal_finance relation with Person_info = " + fkey.getRelationShip());
 
     SqlTable bankInfo = (SqlTable)tables.get("bank_info");
     ForeignKeys ikeys = bankInfo.getExportedKeys();
     ForeignKey nfkey = ikeys.getAssociatedTable("personal_finance");
     System.out.println("Bank_info relation with personal_finance = " + nfkey.getRelationShip());
   }
 }